"""
SBDK CLI commands
"""
