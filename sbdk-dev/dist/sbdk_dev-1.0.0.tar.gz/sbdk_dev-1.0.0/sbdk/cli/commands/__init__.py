"""
SBDK CLI commands
"""