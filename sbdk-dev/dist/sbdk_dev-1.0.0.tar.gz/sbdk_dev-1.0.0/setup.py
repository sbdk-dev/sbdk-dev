"""
Setup script for SBDK.dev package
This is kept minimal as pyproject.toml is the primary configuration
"""
from setuptools import setup

# Use pyproject.toml for all configuration
setup()